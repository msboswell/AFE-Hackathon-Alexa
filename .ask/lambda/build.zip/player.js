const movePlayer = (units, direction) => {
  if (units === undefined) {
    // move continuously
  }
  if (direction === undefined) {
    // default dir = forward?
  }
  // send request to web
}

module.exports = {
  movePlayer
};