const movePlayer = (units, direction) => {
  if (units === undefined) {
    //
  }
  if (direction === undefined) {
    //
  }
  // send request to web
}

module.exports = {
  movePlayer
};